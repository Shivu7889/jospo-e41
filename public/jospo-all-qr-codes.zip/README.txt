# Jospo E41 - Cooler Model QR Labels Archive

This folder contains high-resolution QR codes for all Jospo cooler models.

## How Dispatch QR Scanning Works:
- Each cooler model has its own QR code label.
- When dispatching, the staff scans the label using their mobile camera in the Jospo Dispatch module.
- Each scan adds +1 unit of that model to the vehicle manifest.
- Scanning the same label 10 times counts 10 coolers.

## Folder Contents:
- /png/ - High-resolution PNG images (512x512) for graphic designers or direct printing.
- /svg/ - Vector SVG images for industrial sticker printers.
- printable-labels-sheet.html - Open in Chrome / Safari and press (Cmd+P / Ctrl+P) to print all labels directly onto A4 sticker paper!

Generated on: 11/13/2026, 4:12:35 PM
Unit: Jospo E41 Manufacturing Unit
